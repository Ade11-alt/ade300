document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    var errorMessage = document.getElementById('errorMessage');

    var validUsername = 'user';
    var validPassword = 'password';

    if (username === validUsername && password === validPassword) {
        window.location.href = 'user.html';
    } else {
        errorMessage.textContent = 'Invalid username or password';
    }
});

document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();

    var username = document.getElementById('username').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    var confirmPassword = document.getElementById('confirmPassword').value;
    var errorMessage = document.getElementById('errorMessage');

    if (password !== confirmPassword) {
        errorMessage.textContent = 'Passwords do not match';
        return;
    }

    var users = JSON.parse(localStorage.getItem('users')) || [];
    var userExists = users.some(function(user) {
        return user.username === username || user.email === email;
    });

    if (userExists) {
        errorMessage.textContent = 'Username or email already exists';
    } else {
        users.push({ username: username, email: email, password: password });
        localStorage.setItem('users', JSON.stringify(users));
        alert('Registration successful!');
        window.location.href = 'login.html';
    }
});

function toggleAnger() {
    const angerDiv = document.getElementById('angerDiv');
    const overlay = document.getElementById('overlay');

    if (angerDiv.classList.contains('show')) {
        angerDiv.classList.remove('show'); // Hide the anger div
        overlay.classList.remove('show'); // Hide the overlay
    } else {
        angerDiv.classList.add('show'); // Show the anger div
        overlay.classList.add('show'); // Show the overlay
    }
}

document.getElementById('overlay').addEventListener('click', function () {
    console.log('Overlay clicked');
    const angerDiv = document.getElementById('angerDiv');
    const overlay = document.getElementById('overlay');

    angerDiv.classList.remove('show'); // Hide the anger div
    overlay.classList.remove('show'); // Hide the overlay
});

let toggle = false;

    const connection = SimpleWebSerial.setupSerialConnection();
    document.querySelector('#permissionElement').addEventListener('click', connection.startConnection);

    async function toggleLED() {
        const byte = (toggle = !toggle) ? 0 : 1
        connection.send('led', 0);
    }

